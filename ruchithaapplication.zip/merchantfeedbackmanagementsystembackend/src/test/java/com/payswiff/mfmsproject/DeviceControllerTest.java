package com.payswiff.mfmsproject;


import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payswiff.mfmsproject.controllers.DeviceController;
import com.payswiff.mfmsproject.models.Device;
import com.payswiff.mfmsproject.reuquests.CreateDeviceRequest;
import com.payswiff.mfmsproject.services.DeviceService;

import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {DeviceController.class})
@ExtendWith(SpringExtension.class)
class DeviceControllerTest {
    @Autowired
    private DeviceController deviceController;

    @MockBean
    private DeviceService deviceService; 

    @Test
    @DisplayName("Test createDevice(CreateDeviceRequest)")
    void testCreateDevice() throws Exception {
        // Arrange
        Device device = new Device();
        device.setDeviceCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        device.setDeviceId(1L);
        device.setDeviceManufacturer("Device Manufacturer");
        device.setDeviceModel("Device Model");
        device.setDeviceUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        device.setDeviceUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        
        when(deviceService.saveDevice(Mockito.<Device>any())).thenReturn(device);

        CreateDeviceRequest createDeviceRequest = new CreateDeviceRequest();
        createDeviceRequest.setDeviceManufacturer("Device Manufacturer");
        createDeviceRequest.setDeviceModel("Device Model");
        String content = (new ObjectMapper()).writeValueAsString(createDeviceRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/devices/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);

        // Act and Assert
        MockMvcBuilders.standaloneSetup(deviceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"deviceId\":1,\"deviceUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"deviceModel\":\"Device Model\"," +
                                        "\"deviceManufacturer\":\"Device Manufacturer\",\"deviceCreationTime\":[1970,1,1,0,0],\"deviceUpdationTime\":" +
                                        "[1970,1,1,0,0]}"));
    }

   
}
