package com.payswiff.mfmsproject;

import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payswiff.mfmsproject.controllers.EmployeeController;
import com.payswiff.mfmsproject.models.Employee;
import com.payswiff.mfmsproject.models.EmployeeType;
import com.payswiff.mfmsproject.reuquests.CreateEmployeeRequest;
import com.payswiff.mfmsproject.services.EmployeeService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {EmployeeController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class EmployeeControllerTest {
    @Autowired
    private EmployeeController employeeController;

    @MockBean
    private EmployeeService employeeService;

    /**
     * Test {@link EmployeeController#getEmployee(String, String, String)}.
     * <p>
     * Method under test:
     * {@link EmployeeController#getEmployee(String, String, String)}
     */
    @Test
    @DisplayName("Test getEmployee(String, String, String)")
    void testGetEmployee() throws Exception {
        // Arrange
        Employee employee = new Employee();
        employee.setEmployeeCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        employee.setEmployeeDesignation("Employee Designation");
        employee.setEmployeeEmail("jane.doe@example.org");
        employee.setEmployeeId(1L);
        employee.setEmployeeName("Employee Name");
        employee.setEmployeePassword("gopi@123");
        employee.setEmployeePayswiffId("42");
        employee.setEmployeePhoneNumber("6625550144");
        employee.setEmployeeType(EmployeeType.admin);
        employee.setEmployeeUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        employee.setEmployeeUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        employee.setRoles(new HashSet<>());
        when(employeeService.getEmployee(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(employee);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/employees/get");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(employeeController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"employeeId\":1,\"employeeUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"employeePayswiffId\":\"42\","
                                        + "\"employeeName\":\"Employee Name\",\"employeeEmail\":\"jane.doe@example.org\",\"employeePhoneNumber\":\"6625550144"
                                        + "\",\"employeeDesignation\":\"Employee Designation\",\"employeeType\":\"admin\",\"employeeCreationTime\":[1970,1"
                                        + ",1,0,0],\"employeeUpdationTime\":[1970,1,1,0,0],\"roles\":[]}"));
    }

    /**
     * Test {@link EmployeeController#createEmployee(CreateEmployeeRequest)}.
     * <p>
     * Method under test:
     * {@link EmployeeController#createEmployee(CreateEmployeeRequest)}
     */
    @Test
    @DisplayName("Test createEmployee(CreateEmployeeRequest)")
    void testCreateEmployee() throws Exception {
        // Arrange
        Employee employee = new Employee();
        employee.setEmployeeCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        employee.setEmployeeDesignation("Employee Designation");
        employee.setEmployeeEmail("jane.doe@example.org");
        employee.setEmployeeId(1L);
        employee.setEmployeeName("Employee Name");
        employee.setEmployeePassword("Ruchi@123");
        employee.setEmployeePayswiffId("42");
        employee.setEmployeePhoneNumber("6625550144");
        employee.setEmployeeType(EmployeeType.admin);
        employee.setEmployeeUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        employee.setEmployeeUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        employee.setRoles(new HashSet<>());
        when(employeeService.saveEmployee(Mockito.<Employee>any())).thenReturn(employee);

        CreateEmployeeRequest createEmployeeRequest = new CreateEmployeeRequest();
        createEmployeeRequest.setEmployeeDesignation("Employee Designation");
        createEmployeeRequest.setEmployeeEmail("gopi@gmail.com");
        createEmployeeRequest.setEmployeeName("gopi");
        createEmployeeRequest.setEmployeePassword("gopi@123");
        createEmployeeRequest.setEmployeePayswiffId(1L);
        createEmployeeRequest.setEmployeePhoneNumber("6625550144");
        createEmployeeRequest.setEmployeeType("admin");
        String content = (new ObjectMapper()).writeValueAsString(createEmployeeRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/employees/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);

        // Act
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(employeeController)
                .build()
                .perform(requestBuilder);

        // Assert
        actualPerformResult.andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"employeeId\":1,\"employeeUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"employeePayswiffId\":\"42\","
                                        + "\"employeeName\":\"Employee Name\",\"employeeEmail\":\"jane.doe@example.org\",\"employeePhoneNumber\":\"6625550144"
                                        + "\",\"employeeDesignation\":\"Employee Designation\",\"employeeType\":\"admin\",\"employeeCreationTime\":[1970,1"
                                        + ",1,0,0],\"employeeUpdationTime\":[1970,1,1,0,0],\"roles\":[]}"));
    }

    /**
     * Test {@link EmployeeController#getAllEmployees()}.
     * <p>
     * Method under test: {@link EmployeeController#getAllEmployees()}
     */
    @Test
    @DisplayName("Test getAllEmployees()")
    void testGetAllEmployees() throws Exception {
        // Arrange
        when(employeeService.getAllEmployees()).thenReturn(new ArrayList<>());
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/employees/all");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(employeeController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("[]"));
    }
}
