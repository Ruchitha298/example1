package com.payswiff.mfmsproject;


import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payswiff.mfmsproject.controllers.QuestionController;
import com.payswiff.mfmsproject.models.Question;
import com.payswiff.mfmsproject.reuquests.CreateQuestionRequest;
import com.payswiff.mfmsproject.services.QuestionService;

import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {QuestionController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class QuestionControllerTest {
    @Autowired
    private QuestionController questionController;

    @MockBean
    private QuestionService questionService;

    /**
     * Test {@link QuestionController#getQuestionById(Long)}.
     * <p>
     * Method under test: {@link QuestionController#getQuestionById(Long)}
     */
    @Test
    @DisplayName("Test getQuestionById(Long)")
    void testGetQuestionById() throws Exception {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("Question Description");
        question.setQuestionId(1L);
        question.setQuestionUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        when(questionService.getQuestionById(Mockito.<Long>any())).thenReturn(question);
        MockHttpServletRequestBuilder getResult = MockMvcRequestBuilders.get("/api/questions/get");
        MockHttpServletRequestBuilder requestBuilder = getResult.param("id", String.valueOf(1L));

        // Act and Assert
        MockMvcBuilders.standaloneSetup(questionController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"questionId\":1,\"questionUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"questionDescription\":\"Question"
                                        + " Description\"}"));
    }

    /**
     * Test {@link QuestionController#getQuestionByDescription(String)}.
     * <p>
     * Method under test:
     * {@link QuestionController#getQuestionByDescription(String)}
     */
    @Test
    @DisplayName("Test getQuestionByDescription(String)")
    void testGetQuestionByDescription() throws Exception {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("Question Description");
        question.setQuestionId(1L);
        question.setQuestionUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        when(questionService.getQuestionByDescription(Mockito.<String>any())).thenReturn(question);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/questions/getbydesc")
                .param("description", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(questionController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"questionId\":1,\"questionUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"questionDescription\":\"Question"
                                        + " Description\"}"));
    }

    /**
     * Test {@link QuestionController#createQuestion(CreateQuestionRequest)}.
     * <p>
     * Method under test:
     * {@link QuestionController#createQuestion(CreateQuestionRequest)}
     */
    @Test
    @DisplayName("Test createQuestion(CreateQuestionRequest)")
    void testCreateQuestion() throws Exception {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("Question Description");
        question.setQuestionId(1L);
        question.setQuestionUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        when(questionService.saveQuestion(Mockito.<Question>any())).thenReturn(question);

        CreateQuestionRequest createQuestionRequest = new CreateQuestionRequest();
        createQuestionRequest.setQuestionDescription("Question Description");
        String content = (new ObjectMapper()).writeValueAsString(createQuestionRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/questions/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);

        // Act
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(questionController)
                .build()
                .perform(requestBuilder);

        // Assert
        actualPerformResult.andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"questionId\":1,\"questionUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"questionDescription\":\"Question"
                                        + " Description\"}"));
    }

    /**
     * Test {@link QuestionController#getAllQuestions()}.
     * <p>
     * Method under test: {@link QuestionController#getAllQuestions()}
     */
    @Test
    @DisplayName("Test getAllQuestions()")
    void testGetAllQuestions() throws Exception {
        // Arrange
        when(questionService.getAllQuestions()).thenReturn(new ArrayList<>());
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/questions/all");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(questionController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("[]"));
    }
}
