package com.payswiff.mfmsproject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.payswiff.mfmsproject.exceptions.ResourceAlreadyExists;
import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.exceptions.ResourceUnableToCreate;
import com.payswiff.mfmsproject.models.Device;
import com.payswiff.mfmsproject.repositories.DeviceRepository;
import com.payswiff.mfmsproject.services.DeviceService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {DeviceService.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class DeviceServiceTest {
    @MockBean
    private DeviceRepository deviceRepository;

    @Autowired
    private DeviceService deviceService;

    /**
     * Test {@link DeviceService#saveDevice(Device)}.
     * <p>
     * Method under test: {@link DeviceService#saveDevice(Device)}
     */
    @Test
    @DisplayName("Test saveDevice(Device)")
    void testSaveDevice() throws ResourceAlreadyExists, ResourceUnableToCreate {
        // Arrange
        Device device1 = new Device();
        device1.setDeviceCreationTime(LocalDateTime.of(2024,10,15,10,16,50,893657));
        device1.setDeviceId(1L);
        device1.setDeviceManufacturer("nexigo");
        device1.setDeviceModel("mpos");
        device1.setDeviceUpdationTime(LocalDateTime.of(2024,10,15,10,16,50,893657));
        device1.setDeviceUuid("3aa753ad-4017-4f4c-bf24-dca9c5d5b350");
        when(deviceRepository.findByModel("mpos")).thenReturn(device1);

        Device device2 = new Device();
        device2.setDeviceCreationTime(LocalDateTime.of(2024,10,15,10,16,14,614744));
        device2.setDeviceId(2L);
        device2.setDeviceManufacturer("nexigo");
        device2.setDeviceModel("pos");
        device2.setDeviceUpdationTime(LocalDateTime.of(2024,10,15,10,16,14,614744));
        device2.setDeviceUuid("7d1151ac-77ad-42f8-9b00-9ed443255c26");

        // Act and Assert
        assertThrows(ResourceUnableToCreate.class, () -> deviceService.saveDevice(device2));
        verify(deviceRepository).findByModel(eq("Device Model"));
    }

    /**
     * Test {@link DeviceService#getDeviceByModel(String)}.
     * <p>
     * Method under test: {@link DeviceService#getDeviceByModel(String)}
     */
    @Test
    @DisplayName("Test getDeviceByModel(String)")
    void testGetDeviceByModel() throws ResourceNotFoundException {
        // Arrange
        Device device1 = new Device();
        device1.setDeviceCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        device1.setDeviceId(1L);
        device1.setDeviceManufacturer("nexigo");
        device1.setDeviceModel("mpos");
        device1.setDeviceUpdationTime(LocalDateTime.of(2024,10,15,10,16,50,893657));
        device1.setDeviceUuid("3aa753ad-4017-4f4c-bf24-dca9c5d5b350");
        when(deviceRepository.findByModel(Mockito.<String>any())).thenReturn(device1);

        // Act
        ResponseEntity<Device> actualDeviceByModel = deviceService.getDeviceByModel("mpos");

        // Assert
        verify(deviceRepository).findByModel(eq("mpos"));
        assertEquals(HttpStatus.OK, actualDeviceByModel.getStatusCode());
        assertTrue(actualDeviceByModel.hasBody());
        assertEquals(device1, actualDeviceByModel.getBody());
    }

    /**
     * Test {@link DeviceService#getAllDevices()}.
     * <p>
     * Method under test: {@link DeviceService#getAllDevices()}
     */
    @Test
    @DisplayName("Test getAllDevices()")
    void testGetAllDevices() {
        // Arrange
        when(deviceRepository.findAll()).thenReturn(new ArrayList<>());

        // Act
        List<Device> actualAllDevices = deviceService.getAllDevices();

        // Assert
        verify(deviceRepository).findAll();
        assertTrue(actualAllDevices.isEmpty());
    }

    /**
     * Test {@link DeviceService#existsById(Long)}.
     * <ul>
     *   <li>Given {@link DeviceRepository} {@link CrudRepository#existsById(Object)}
     * return {@code false}.</li>
     *   <li>Then return {@code false}.</li>
     * </ul>
     * <p>
     * Method under test: {@link DeviceService#existsById(Long)}
     */
    @Test
    @DisplayName("Test existsById(Long); given DeviceRepository existsById(Object) return 'false'; then return 'false'")
    void testExistsById_givenDeviceRepositoryExistsByIdReturnFalse_thenReturnFalse() {
        // Arrange
        when(deviceRepository.existsById(Mockito.<Long>any())).thenReturn(false);

        // Act
        boolean actualExistsByIdResult = deviceService.existsById(1L);

        // Assert
        verify(deviceRepository).existsById(eq(1L));
        assertFalse(actualExistsByIdResult);
    }

    /**
     * Test {@link DeviceService#existsById(Long)}.
     * <ul>
     *   <li>Given {@link DeviceRepository} {@link CrudRepository#existsById(Object)}
     * return {@code true}.</li>
     *   <li>When one.</li>
     *   <li>Then return {@code true}.</li>
     * </ul>
     * <p>
     * Method under test: {@link DeviceService#existsById(Long)}
     */
    @Test
    @DisplayName("Test existsById(Long); given DeviceRepository existsById(Object) return 'true'; when one; then return 'true'")
    void testExistsById_givenDeviceRepositoryExistsByIdReturnTrue_whenOne_thenReturnTrue() {
        // Arrange
        when(deviceRepository.existsById(Mockito.<Long>any())).thenReturn(true);

        // Act
        boolean actualExistsByIdResult = deviceService.existsById(1L);

        // Assert
        verify(deviceRepository).existsById(eq(1L));
        assertTrue(actualExistsByIdResult);
    }

    /**
     * Test {@link DeviceService#existsById(Long)}.
     * <ul>
     *   <li>When {@code null}.</li>
     *   <li>Then return {@code false}.</li>
     * </ul>
     * <p>
     * Method under test: {@link DeviceService#existsById(Long)}
     */
    @Test
    @DisplayName("Test existsById(Long); when 'null'; then return 'false'")
    void testExistsById_whenNull_thenReturnFalse() {
        // Arrange, Act and Assert
        assertFalse(deviceService.existsById(null));
    }
}

