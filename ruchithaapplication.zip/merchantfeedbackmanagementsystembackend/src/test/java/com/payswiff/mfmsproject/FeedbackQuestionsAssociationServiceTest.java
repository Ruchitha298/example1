package com.payswiff.mfmsproject;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.models.Device;
import com.payswiff.mfmsproject.models.Employee;
import com.payswiff.mfmsproject.models.EmployeeType;
import com.payswiff.mfmsproject.models.Feedback;
import com.payswiff.mfmsproject.models.FeedbackQuestionsAssociation;
import com.payswiff.mfmsproject.models.Merchant;
import com.payswiff.mfmsproject.models.Question;
import com.payswiff.mfmsproject.repositories.FeedbackQuestionsAssociationRepository;
import com.payswiff.mfmsproject.repositories.FeedbackRepository;
import com.payswiff.mfmsproject.repositories.QuestionRepository;
import com.payswiff.mfmsproject.services.FeedbackQuestionsAssociationService;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {FeedbackQuestionsAssociationService.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class FeedbackQuestionsAssociationServiceTest {
    @MockBean
    private FeedbackQuestionsAssociationRepository feedbackQuestionsAssociationRepository;

    @Autowired
    private FeedbackQuestionsAssociationService feedbackQuestionsAssociationService;

    @MockBean
    private FeedbackRepository feedbackRepository;

    @MockBean
    private QuestionRepository questionRepository;

    /**
     * Test
     * {@link FeedbackQuestionsAssociationService#createAssociation(FeedbackQuestionsAssociation)}.
     * <p>
     * Method under test:
     * {@link FeedbackQuestionsAssociationService#createAssociation(FeedbackQuestionsAssociation)}
     */
    @Test
    @DisplayName("Test createAssociation(FeedbackQuestionsAssociation)")
    void testCreateAssociation() throws ResourceNotFoundException {
        // Arrange
        Device feedbackDevice = new Device();
        feedbackDevice.setDeviceCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackDevice.setDeviceId(1L);
        feedbackDevice.setDeviceManufacturer("Device Manufacturer");
        feedbackDevice.setDeviceModel("Device Model");
        feedbackDevice.setDeviceUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackDevice.setDeviceUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Employee feedbackEmployee = new Employee();
        feedbackEmployee.setEmployeeCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackEmployee.setEmployeeDesignation("Employee Designation");
        feedbackEmployee.setEmployeeEmail("jane.doe@example.org");
        feedbackEmployee.setEmployeeId(1L);
        feedbackEmployee.setEmployeeName("Employee Name");
        feedbackEmployee.setEmployeePassword("iloveyou");
        feedbackEmployee.setEmployeePayswiffId("42");
        feedbackEmployee.setEmployeePhoneNumber("6625550144");
        feedbackEmployee.setEmployeeType(EmployeeType.admin);
        feedbackEmployee.setEmployeeUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackEmployee.setEmployeeUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Merchant feedbackMerchant = new Merchant();
        feedbackMerchant.setMerchantBusinessName("Merchant Business Name");
        feedbackMerchant.setMerchantBusinessType("Merchant Business Type");
        feedbackMerchant.setMerchantCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackMerchant.setMerchantEmail("jane.doe@example.org");
        feedbackMerchant.setMerchantId(1L);
        feedbackMerchant.setMerchantPhone("6625550144");
        feedbackMerchant.setMerchantUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackMerchant.setMerchantUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Feedback feedback = new Feedback();
        feedback.setFeedback("Feedback");
        feedback.setFeedbackCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedback.setFeedbackDevice(feedbackDevice);
        feedback.setFeedbackEmployee(feedbackEmployee);
        feedback.setFeedbackId(1);
        feedback.setFeedbackImage1("Feedback Image1");
        feedback.setFeedbackMerchant(feedbackMerchant);
        feedback.setFeedbackRating(10.0d);
        feedback.setFeedbackUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedback.setFeedbackUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Question question = new Question();
        question.setQuestionDescription("Question Description");
        question.setQuestionId(1L);
        question.setQuestionUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        FeedbackQuestionsAssociation feedbackQuestionsAssociation = new FeedbackQuestionsAssociation();
        feedbackQuestionsAssociation.setAnswer("Answer");
        feedbackQuestionsAssociation.setFeedback(feedback);
        feedbackQuestionsAssociation.setId(1);
        feedbackQuestionsAssociation.setQuestion(question);
        when(feedbackQuestionsAssociationRepository.save(Mockito.<FeedbackQuestionsAssociation>any()))
                .thenReturn(feedbackQuestionsAssociation);

        Device feedbackDevice2 = new Device();
        feedbackDevice2.setDeviceCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackDevice2.setDeviceId(1L);
        feedbackDevice2.setDeviceManufacturer("Device Manufacturer");
        feedbackDevice2.setDeviceModel("Device Model");
        feedbackDevice2.setDeviceUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackDevice2.setDeviceUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Employee feedbackEmployee2 = new Employee();
        feedbackEmployee2.setEmployeeCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackEmployee2.setEmployeeDesignation("Employee Designation");
        feedbackEmployee2.setEmployeeEmail("jane.doe@example.org");
        feedbackEmployee2.setEmployeeId(1L);
        feedbackEmployee2.setEmployeeName("Employee Name");
        feedbackEmployee2.setEmployeePassword("iloveyou");
        feedbackEmployee2.setEmployeePayswiffId("42");
        feedbackEmployee2.setEmployeePhoneNumber("6625550144");
        feedbackEmployee2.setEmployeeType(EmployeeType.admin);
        feedbackEmployee2.setEmployeeUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackEmployee2.setEmployeeUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Merchant feedbackMerchant2 = new Merchant();
        feedbackMerchant2.setMerchantBusinessName("Merchant Business Name");
        feedbackMerchant2.setMerchantBusinessType("Merchant Business Type");
        feedbackMerchant2.setMerchantCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackMerchant2.setMerchantEmail("jane.doe@example.org");
        feedbackMerchant2.setMerchantId(1L);
        feedbackMerchant2.setMerchantPhone("6625550144");
        feedbackMerchant2.setMerchantUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackMerchant2.setMerchantUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Feedback feedback2 = new Feedback();
        feedback2.setFeedback("Feedback");
        feedback2.setFeedbackCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedback2.setFeedbackDevice(feedbackDevice2);
        feedback2.setFeedbackEmployee(feedbackEmployee2);
        feedback2.setFeedbackId(1);
        feedback2.setFeedbackImage1("Feedback Image1");
        feedback2.setFeedbackMerchant(feedbackMerchant2);
        feedback2.setFeedbackRating(10.0d);
        feedback2.setFeedbackUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedback2.setFeedbackUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        Optional<Feedback> ofResult = Optional.of(feedback2);
        when(feedbackRepository.findById(Mockito.<Integer>any())).thenReturn(ofResult);

        Question question2 = new Question();
        question2.setQuestionDescription("Question Description");
        question2.setQuestionId(1L);
        question2.setQuestionUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        Optional<Question> ofResult2 = Optional.of(question2);
        when(questionRepository.findById(Mockito.<Long>any())).thenReturn(ofResult2);

        Device feedbackDevice3 = new Device();
        feedbackDevice3.setDeviceCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackDevice3.setDeviceId(1L);
        feedbackDevice3.setDeviceManufacturer("Device Manufacturer");
        feedbackDevice3.setDeviceModel("Device Model");
        feedbackDevice3.setDeviceUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackDevice3.setDeviceUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Employee feedbackEmployee3 = new Employee();
        feedbackEmployee3.setEmployeeCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackEmployee3.setEmployeeDesignation("Employee Designation");
        feedbackEmployee3.setEmployeeEmail("jane.doe@example.org");
        feedbackEmployee3.setEmployeeId(1L);
        feedbackEmployee3.setEmployeeName("Employee Name");
        feedbackEmployee3.setEmployeePassword("iloveyou");
        feedbackEmployee3.setEmployeePayswiffId("42");
        feedbackEmployee3.setEmployeePhoneNumber("6625550144");
        feedbackEmployee3.setEmployeeType(EmployeeType.admin);
        feedbackEmployee3.setEmployeeUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackEmployee3.setEmployeeUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Merchant feedbackMerchant3 = new Merchant();
        feedbackMerchant3.setMerchantBusinessName("Merchant Business Name");
        feedbackMerchant3.setMerchantBusinessType("Merchant Business Type");
        feedbackMerchant3.setMerchantCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackMerchant3.setMerchantEmail("jane.doe@example.org");
        feedbackMerchant3.setMerchantId(1L);
        feedbackMerchant3.setMerchantPhone("6625550144");
        feedbackMerchant3.setMerchantUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedbackMerchant3.setMerchantUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Feedback feedback3 = new Feedback();
        feedback3.setFeedback("Feedback");
        feedback3.setFeedbackCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedback3.setFeedbackDevice(feedbackDevice3);
        feedback3.setFeedbackEmployee(feedbackEmployee3);
        feedback3.setFeedbackId(1);
        feedback3.setFeedbackImage1("Feedback Image1");
        feedback3.setFeedbackMerchant(feedbackMerchant3);
        feedback3.setFeedbackRating(10.0d);
        feedback3.setFeedbackUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        feedback3.setFeedbackUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        Question question3 = new Question();
        question3.setQuestionDescription("Question Description");
        question3.setQuestionId(1L);
        question3.setQuestionUuid("01234567-89AB-CDEF-FEDC-BA9876543210");

        FeedbackQuestionsAssociation request = new FeedbackQuestionsAssociation();
        request.setAnswer("Answer");
        request.setFeedback(feedback3);
        request.setId(1);
        request.setQuestion(question3);

        // Act
        FeedbackQuestionsAssociation actualCreateAssociationResult = feedbackQuestionsAssociationService
                .createAssociation(request);

        // Assert
        verify(questionRepository).findById(eq(1L));
        verify(feedbackRepository).findById(eq(1));
        verify(feedbackQuestionsAssociationRepository).save(isA(FeedbackQuestionsAssociation.class));
        assertSame(feedbackQuestionsAssociation, actualCreateAssociationResult);
    }
}
