package com.payswiff.mfmsproject;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payswiff.mfmsproject.controllers.AuthController;
import com.payswiff.mfmsproject.dtos.ForgotPasswordDto;
import com.payswiff.mfmsproject.dtos.LoginDto;
import com.payswiff.mfmsproject.dtos.LoginResponseDto;
import com.payswiff.mfmsproject.exceptions.EmployeePasswordUpdationFailedException;
import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.services.AuthService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private AuthService authService;

    @InjectMocks
    private AuthController authController;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
    }

    @Test
    @DisplayName("Test login endpoint")
    void testLogin() throws Exception {
        // Arrange
        LoginDto loginDto = new LoginDto("6625550144", "Ruchi@123");
        LoginResponseDto loginResponseDto = new LoginResponseDto("6625550144", "Login successful");
        
        // Mock the authentication behavior
        when(authService.login(loginDto)).thenReturn(loginResponseDto);

        // Act & Assert
        mockMvc.perform(MockMvcRequestBuilders.post("/api/authentication/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginDto)))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(objectMapper.writeValueAsString(loginResponseDto)));
    }


    @Test
    @DisplayName("Test forgot password endpoint")
    void testForgotPassword() throws Exception {
        // Arrange
        ForgotPasswordDto forgotPasswordDto = new ForgotPasswordDto("john.doe@example.com", "newPassword123");  // Use email instead of phone
        when(authService.forgotPassword(forgotPasswordDto)).thenReturn(true);

        // Act & Assert
        mockMvc.perform(MockMvcRequestBuilders.post("/api/authentication/forgotpassword")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(forgotPasswordDto)))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

    @Test
    @DisplayName("Test forgot password with exceptions")
    void testForgotPasswordWithException() throws Exception {
        // Arrange
        ForgotPasswordDto forgotPasswordDto = new ForgotPasswordDto("john.doe@example.com", "newPassword123");  // Use email instead of phone
        when(authService.forgotPassword(forgotPasswordDto)).thenThrow(new ResourceNotFoundException("Employee not found"));

        // Act & Assert
        mockMvc.perform(MockMvcRequestBuilders.post("/api/authentication/forgotpassword")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(forgotPasswordDto)))
                .andExpect(status().isNotFound());
    }
}
