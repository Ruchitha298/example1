package com.payswiff.mfmsproject;


import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.payswiff.mfmsproject.exceptions.ResourceAlreadyExists;
import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.exceptions.UnableSentEmail;
import com.payswiff.mfmsproject.models.Employee;
import com.payswiff.mfmsproject.models.EmployeeType;
import com.payswiff.mfmsproject.repositories.EmployeeRepository;
import com.payswiff.mfmsproject.repositories.RoleRepository;
import com.payswiff.mfmsproject.services.EmailService;
import com.payswiff.mfmsproject.services.EmployeeService;

import java.time.LocalDate;
import java.util.HashSet;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {EmployeeService.class, PasswordEncoder.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class EmployeeServiceDiffblueTest {
    @MockBean
    private EmailService emailService;

    @MockBean
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeService employeeService;

    @MockBean
    private PasswordEncoder passwordEncoder;

    @MockBean
    private RoleRepository roleRepository;

    /**
     * Test {@link EmployeeService#saveEmployee(Employee)}.
     * <p>
     * Method under test: {@link EmployeeService#saveEmployee(Employee)}
     */
    @Test
    @DisplayName("Test saveEmployee(Employee)")
    @Disabled("TODO: Complete this test")
    void testSaveEmployee() throws ResourceAlreadyExists, ResourceNotFoundException, UnableSentEmail {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Reason: Failed to create Spring context.
        //   Attempt to initialize test context failed with
        //   java.lang.IllegalStateException: ApplicationContext failure threshold (1) exceeded: skipping repeated attempt to load context for [MergedContextConfiguration@404352d5 testClass = com.payswiff.mfmsproject.services.DiffblueFakeClass82, locations = [], classes = [com.payswiff.mfmsproject.services.EmployeeService, org.springframework.security.crypto.password.PasswordEncoder], contextInitializerClasses = [], activeProfiles = [], propertySourceDescriptors = [], propertySourceProperties = [], contextCustomizers = [org.springframework.boot.test.context.filter.ExcludeFilterContextCustomizer@72d248d0, org.springframework.boot.test.json.DuplicateJsonObjectContextCustomizerFactory$DuplicateJsonObjectContextCustomizer@237a1b24, org.springframework.boot.test.mock.mockito.MockitoContextCustomizer@be59dc41, org.springframework.boot.test.web.reactor.netty.DisableReactorResourceFactoryGlobalResourcesContextCustomizerFactory$DisableReactorResourceFactoryGlobalResourcesContextCustomizerCustomizer@c4c210c, org.springframework.boot.test.autoconfigure.actuate.observability.ObservabilityContextCustomizerFactory$DisableObservabilityContextCustomizer@1f, org.springframework.boot.test.autoconfigure.properties.PropertyMappingContextCustomizer@0, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverContextCustomizer@7b64698f], contextLoader = org.springframework.test.context.support.DelegatingSmartContextLoader, parent = null]
        //       at org.springframework.test.context.cache.DefaultCacheAwareContextLoaderDelegate.loadContext(DefaultCacheAwareContextLoaderDelegate.java:145)
        //       at org.springframework.test.context.support.DefaultTestContext.getApplicationContext(DefaultTestContext.java:130)
        //       at java.base/java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:212)
        //       at java.base/java.util.ArrayList$ArrayListSpliterator.forEachRemaining(ArrayList.java:1709)
        //       at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:556)
        //       at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:546)
        //       at java.base/java.util.stream.ReduceOps$ReduceOp.evaluateSequential(ReduceOps.java:921)
        //       at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        //       at java.base/java.util.stream.ReferencePipeline.collect(ReferencePipeline.java:702)
        //   See https://diff.blue/R026 to resolve this issue.

        // Arrange
        Employee employee = new Employee();
        employee.setEmployeeCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        employee.setEmployeeDesignation("Employee Designation");
        employee.setEmployeeEmail("jane.doe@example.org");
        employee.setEmployeeId(1L);
        employee.setEmployeeName("Employee Name");
        employee.setEmployeePassword("iloveyou");
        employee.setEmployeePayswiffId("42");
        employee.setEmployeePhoneNumber("6625550144");
        employee.setEmployeeType(EmployeeType.admin);
        employee.setEmployeeUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        employee.setEmployeeUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        employee.setRoles(new HashSet<>());

        // Act
        employeeService.saveEmployee(employee);
    }

    /**
     * Test {@link EmployeeService#getEmployee(String, String, String)}.
     * <p>
     * Method under test:
     * {@link EmployeeService#getEmployee(String, String, String)}
     */
    @Test
    @DisplayName("Test getEmployee(String, String, String)")
    @Disabled("TODO: Complete this test")
    void testGetEmployee() throws ResourceNotFoundException {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Reason: Failed to create Spring context.
        //   Attempt to initialize test context failed with
        //   java.lang.IllegalStateException: ApplicationContext failure threshold (1) exceeded: skipping repeated attempt to load context for [MergedContextConfiguration@73b72e30 testClass = com.payswiff.mfmsproject.services.DiffblueFakeClass81, locations = [], classes = [com.payswiff.mfmsproject.services.EmployeeService, org.springframework.security.crypto.password.PasswordEncoder], contextInitializerClasses = [], activeProfiles = [], propertySourceDescriptors = [], propertySourceProperties = [], contextCustomizers = [org.springframework.boot.test.context.filter.ExcludeFilterContextCustomizer@72d248d0, org.springframework.boot.test.json.DuplicateJsonObjectContextCustomizerFactory$DuplicateJsonObjectContextCustomizer@237a1b24, org.springframework.boot.test.mock.mockito.MockitoContextCustomizer@be59dc41, org.springframework.boot.test.web.reactor.netty.DisableReactorResourceFactoryGlobalResourcesContextCustomizerFactory$DisableReactorResourceFactoryGlobalResourcesContextCustomizerCustomizer@c4c210c, org.springframework.boot.test.autoconfigure.actuate.observability.ObservabilityContextCustomizerFactory$DisableObservabilityContextCustomizer@1f, org.springframework.boot.test.autoconfigure.properties.PropertyMappingContextCustomizer@0, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverContextCustomizer@7b64698f], contextLoader = org.springframework.test.context.support.DelegatingSmartContextLoader, parent = null]
        //       at org.springframework.test.context.cache.DefaultCacheAwareContextLoaderDelegate.loadContext(DefaultCacheAwareContextLoaderDelegate.java:145)
        //       at org.springframework.test.context.support.DefaultTestContext.getApplicationContext(DefaultTestContext.java:130)
        //       at java.base/java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:212)
        //       at java.base/java.util.ArrayList$ArrayListSpliterator.forEachRemaining(ArrayList.java:1709)
        //       at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:556)
        //       at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:546)
        //       at java.base/java.util.stream.ReduceOps$ReduceOp.evaluateSequential(ReduceOps.java:921)
        //       at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        //       at java.base/java.util.stream.ReferencePipeline.collect(ReferencePipeline.java:702)
        //   See https://diff.blue/R026 to resolve this issue.

        // Arrange and Act
        employeeService.getEmployee("42", "6625550144", "jane.doe@example.org");
    }

    /**
     * Test {@link EmployeeService#getEmployee(String, String, String)}.
     * <ul>
     *   <li>When {@code null}.</li>
     *   <li>Then throw {@link ResourceNotFoundException}.</li>
     * </ul>
     * <p>
     * Method under test:
     * {@link EmployeeService#getEmployee(String, String, String)}
     */
    @Test
    @DisplayName("Test getEmployee(String, String, String); when 'null'; then throw ResourceNotFoundException")
    void testGetEmployee_whenNull_thenThrowResourceNotFoundException() throws ResourceNotFoundException {
        //   Diffblue Cover was unable to create a Spring-specific test for this Spring method.

        // Arrange, Act and Assert
        assertThrows(ResourceNotFoundException.class, () -> (new EmployeeService()).getEmployee(null, null, null));
    }

    /**
     * Test {@link EmployeeService#existsById(Long)}.
     * <ul>
     *   <li>Given {@link EmployeeRepository}
     * {@link CrudRepository#existsById(Object)} return {@code false}.</li>
     *   <li>Then return {@code false}.</li>
     * </ul>
     * <p>
     * Method under test: {@link EmployeeService#existsById(Long)}
     */
    @Test
    @DisplayName("Test existsById(Long); given EmployeeRepository existsById(Object) return 'false'; then return 'false'")
    void testExistsById_givenEmployeeRepositoryExistsByIdReturnFalse_thenReturnFalse() {
        // Arrange
        when(employeeRepository.existsById(Mockito.<Long>any())).thenReturn(false);

        // Act
        boolean actualExistsByIdResult = employeeService.existsById(1L);

        // Assert
        verify(employeeRepository).existsById(eq(1L));
        assertFalse(actualExistsByIdResult);
    }

    /**
     * Test {@link EmployeeService#existsById(Long)}.
     * <ul>
     *   <li>Given {@link EmployeeRepository}
     * {@link CrudRepository#existsById(Object)} return {@code true}.</li>
     *   <li>Then return {@code true}.</li>
     * </ul>
     * <p>
     * Method under test: {@link EmployeeService#existsById(Long)}
     */
    @Test
    @DisplayName("Test existsById(Long); given EmployeeRepository existsById(Object) return 'true'; then return 'true'")
    void testExistsById_givenEmployeeRepositoryExistsByIdReturnTrue_thenReturnTrue() {
        // Arrange
        when(employeeRepository.existsById(Mockito.<Long>any())).thenReturn(true);

        // Act
        boolean actualExistsByIdResult = employeeService.existsById(1L);

        // Assert
        verify(employeeRepository).existsById(eq(1L));
        assertTrue(actualExistsByIdResult);
    }

    /**
     * Test {@link EmployeeService#existsById(Long)}.
     * <ul>
     *   <li>When {@code null}.</li>
     *   <li>Then return {@code false}.</li>
     * </ul>
     * <p>
     * Method under test: {@link EmployeeService#existsById(Long)}
     */
    @Test
    @DisplayName("Test existsById(Long); when 'null'; then return 'false'")
    void testExistsById_whenNull_thenReturnFalse() {
        // Arrange, Act and Assert
        assertFalse(employeeService.existsById(null));
    }

    /**
     * Test {@link EmployeeService#updateEmployeePassword(String, String)}.
     * <p>
     * Method under test:
     * {@link EmployeeService#updateEmployeePassword(String, String)}
     */
    @Test
    @DisplayName("Test updateEmployeePassword(String, String)")
    @Disabled("TODO: Complete this test")
    void testUpdateEmployeePassword() throws ResourceNotFoundException {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Reason: Failed to create Spring context.
        //   Attempt to initialize test context failed with
        //   java.lang.IllegalStateException: ApplicationContext failure threshold (1) exceeded: skipping repeated attempt to load context for [MergedContextConfiguration@2886728c testClass = com.payswiff.mfmsproject.services.DiffblueFakeClass83, locations = [], classes = [com.payswiff.mfmsproject.services.EmployeeService, org.springframework.security.crypto.password.PasswordEncoder], contextInitializerClasses = [], activeProfiles = [], propertySourceDescriptors = [], propertySourceProperties = [], contextCustomizers = [org.springframework.boot.test.context.filter.ExcludeFilterContextCustomizer@72d248d0, org.springframework.boot.test.json.DuplicateJsonObjectContextCustomizerFactory$DuplicateJsonObjectContextCustomizer@237a1b24, org.springframework.boot.test.mock.mockito.MockitoContextCustomizer@be59dc41, org.springframework.boot.test.web.reactor.netty.DisableReactorResourceFactoryGlobalResourcesContextCustomizerFactory$DisableReactorResourceFactoryGlobalResourcesContextCustomizerCustomizer@c4c210c, org.springframework.boot.test.autoconfigure.actuate.observability.ObservabilityContextCustomizerFactory$DisableObservabilityContextCustomizer@1f, org.springframework.boot.test.autoconfigure.properties.PropertyMappingContextCustomizer@0, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverContextCustomizer@7b64698f], contextLoader = org.springframework.test.context.support.DelegatingSmartContextLoader, parent = null]
        //       at org.springframework.test.context.cache.DefaultCacheAwareContextLoaderDelegate.loadContext(DefaultCacheAwareContextLoaderDelegate.java:145)
        //       at org.springframework.test.context.support.DefaultTestContext.getApplicationContext(DefaultTestContext.java:130)
        //       at java.base/java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:212)
        //       at java.base/java.util.ArrayList$ArrayListSpliterator.forEachRemaining(ArrayList.java:1709)
        //       at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:556)
        //       at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:546)
        //       at java.base/java.util.stream.ReduceOps$ReduceOp.evaluateSequential(ReduceOps.java:921)
        //       at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        //       at java.base/java.util.stream.ReferencePipeline.collect(ReferencePipeline.java:702)
        //   See https://diff.blue/R026 to resolve this issue.

        // Arrange and Act
        employeeService.updateEmployeePassword("jane.doe@example.org", "iloveyou");
    }

    /**
     * Test {@link EmployeeService#getAllEmployees()}.
     * <p>
     * Method under test: {@link EmployeeService#getAllEmployees()}
     */
    @Test
    @DisplayName("Test getAllEmployees()")
    @Disabled("TODO: Complete this test")
    void testGetAllEmployees() {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Reason: Failed to create Spring context.
        //   Attempt to initialize test context failed with
        //   java.lang.IllegalStateException: ApplicationContext failure threshold (1) exceeded: skipping repeated attempt to load context for [MergedContextConfiguration@6f3a46d2 testClass = com.payswiff.mfmsproject.services.DiffblueFakeClass80, locations = [], classes = [com.payswiff.mfmsproject.services.EmployeeService, org.springframework.security.crypto.password.PasswordEncoder], contextInitializerClasses = [], activeProfiles = [], propertySourceDescriptors = [], propertySourceProperties = [], contextCustomizers = [org.springframework.boot.test.context.filter.ExcludeFilterContextCustomizer@72d248d0, org.springframework.boot.test.json.DuplicateJsonObjectContextCustomizerFactory$DuplicateJsonObjectContextCustomizer@237a1b24, org.springframework.boot.test.mock.mockito.MockitoContextCustomizer@be59dc41, org.springframework.boot.test.web.reactor.netty.DisableReactorResourceFactoryGlobalResourcesContextCustomizerFactory$DisableReactorResourceFactoryGlobalResourcesContextCustomizerCustomizer@c4c210c, org.springframework.boot.test.autoconfigure.actuate.observability.ObservabilityContextCustomizerFactory$DisableObservabilityContextCustomizer@1f, org.springframework.boot.test.autoconfigure.properties.PropertyMappingContextCustomizer@0, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverContextCustomizer@7b64698f], contextLoader = org.springframework.test.context.support.DelegatingSmartContextLoader, parent = null]
        //       at org.springframework.test.context.cache.DefaultCacheAwareContextLoaderDelegate.loadContext(DefaultCacheAwareContextLoaderDelegate.java:145)
        //       at org.springframework.test.context.support.DefaultTestContext.getApplicationContext(DefaultTestContext.java:130)
        //       at java.base/java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:212)
        //       at java.base/java.util.ArrayList$ArrayListSpliterator.forEachRemaining(ArrayList.java:1709)
        //       at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:556)
        //       at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:546)
        //       at java.base/java.util.stream.ReduceOps$ReduceOp.evaluateSequential(ReduceOps.java:921)
        //       at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
        //       at java.base/java.util.stream.ReferencePipeline.collect(ReferencePipeline.java:702)
        //   See https://diff.blue/R026 to resolve this issue.

        // Arrange and Act
        employeeService.getAllEmployees();
    }
}
