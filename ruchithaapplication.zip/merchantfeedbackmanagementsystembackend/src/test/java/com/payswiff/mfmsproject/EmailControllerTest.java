package com.payswiff.mfmsproject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payswiff.mfmsproject.controllers.EmailController;
import com.payswiff.mfmsproject.dtos.EmailSendDto;
import com.payswiff.mfmsproject.services.EmailService;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {EmailController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class EmailControllerTest {
    @Autowired
    private EmailController emailController;

    @MockBean
    private EmailService emailService;

    /**
     * Test {@link EmailController#generateOtp(String)}.
     * <p>
     * Method under test: {@link EmailController#generateOtp(String)}
     */
    @Test
    @DisplayName("Test generateOtp(String)")
    @Disabled("TODO: Complete this test")
    void testGenerateOtp() throws Exception {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Diffblue AI was unable to find a test

        // Arrange
        // TODO: Populate arranged inputs
        Object[] uriVariables = new Object[]{};
        String[] values = new String[]{"foo"};
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/email/generateOTP", uriVariables)
                .param("email", values);
        Object[] controllers = new Object[]{emailController};
        MockMvc buildResult = MockMvcBuilders.standaloneSetup(controllers).build();

        // Act
        ResultActions actualPerformResult = buildResult.perform(requestBuilder);

        // Assert
        // TODO: Add assertions on result
    }

    /**
     * Test {@link EmailController#sendEmail(EmailSendDto)}.
     * <p>
     * Method under test: {@link EmailController#sendEmail(EmailSendDto)}
     */
    @Test
    @DisplayName("Test sendEmail(EmailSendDto)")
    @Disabled("TODO: Complete this test")
    void testSendEmail() throws Exception {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Diffblue AI was unable to find a test

        // Arrange
        // TODO: Populate arranged inputs
        Object[] uriVariables = new Object[]{};
        MockHttpServletRequestBuilder contentTypeResult = MockMvcRequestBuilders.post("/api/email/send-email", uriVariables)
                .contentType(MediaType.APPLICATION_JSON);

        EmailSendDto emailSendDto = new EmailSendDto();
        emailSendDto.setSubject("Hello from the Dreaming Spires");
        emailSendDto.setText("Text");
        emailSendDto.setTo("alice.liddell@example.org");

        ObjectMapper objectMapper = new ObjectMapper();
        MockHttpServletRequestBuilder requestBuilder = contentTypeResult
                .content(objectMapper.writeValueAsString(emailSendDto));
        Object[] controllers = new Object[]{emailController};
        MockMvc buildResult = MockMvcBuilders.standaloneSetup(controllers).build();

        // Act
        ResultActions actualPerformResult = buildResult.perform(requestBuilder);

        // Assert
        // TODO: Add assertions on result
    }
}
