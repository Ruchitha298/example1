package com.payswiff.mfmsproject;


import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.payswiff.mfmsproject.dtos.ForgotPasswordDto;
import com.payswiff.mfmsproject.dtos.LoginDto;
import com.payswiff.mfmsproject.exceptions.EmployeePasswordUpdationFailedException;
import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.repositories.EmployeeRepository;
import com.payswiff.mfmsproject.security.CustomeUserDetailsService;
import com.payswiff.mfmsproject.security.JwtAuthenticationEntryPoint;
import com.payswiff.mfmsproject.security.JwtAuthenticationFilter;
import com.payswiff.mfmsproject.security.JwtTokenProvider;
import com.payswiff.mfmsproject.services.AuthService;
import com.payswiff.mfmsproject.services.EmployeeService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {AuthService.class, AuthenticationManager.class})
@ExtendWith(SpringExtension.class)
class AuthServiceTest {

    @Autowired
    private AuthService authService;

    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private CustomeUserDetailsService customeUserDetailsService;

    @MockBean
    private EmployeeRepository employeeRepository;

    @MockBean
    private EmployeeService employeeService;

    @MockBean
    private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;

    @MockBean
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @MockBean
    private JwtTokenProvider jwtTokenProvider;

    /**
     * Test {@link AuthService#login(LoginDto)}.
     */
    @Test
    @DisplayName("Test login(LoginDto); when LoginDto(String, String) with email is 'john.doe@example.com' and password is 'ruchi@123'")
    void testLogin_whenLoginDtoWithEmailIsJohnDoeAndPasswordIsRuchi123() {
        // Arrange
        LoginDto loginDto = new LoginDto("john.doe@example.com", "ruchi@123");
        // Mock any behavior for authenticationManager and customeUserDetailsService if needed

        // Act
        // Call the login method (this needs to be implemented correctly)
        authService.login(loginDto);
        
        // Assert
        // Verify expected outcomes (this needs to be implemented correctly)
        // e.g., verify(authenticationManager, times(1)).authenticate(...);
    }

    /**
     * Test {@link AuthService#forgotPassword(ForgotPasswordDto)}.
     */
    @Test
    @DisplayName("Test forgotPassword(ForgotPasswordDto) with existing email and successful password update")
    void testForgotPassword() throws EmployeePasswordUpdationFailedException, ResourceNotFoundException {
        // Arrange
        when(employeeRepository.existsByEmployeeEmail(Mockito.<String>any())).thenReturn(true);
        when(employeeService.updateEmployeePassword(Mockito.<String>any(), Mockito.<String>any())).thenReturn(true);

        // Act
        boolean result = authService.forgotPassword(new ForgotPasswordDto("john.doe@example.com", "ruchi23"));

        // Assert
        verify(employeeRepository).existsByEmployeeEmail(eq("john.doe@example.com"));
        verify(employeeService).updateEmployeePassword(eq("john.doe@example.com"), eq("ruchi23"));
        assertTrue(result);
    }

    /**
     * Test {@link AuthService#forgotPassword(ForgotPasswordDto)} when email does not exist.
     */
    @Test
    @DisplayName("Test forgotPassword(ForgotPasswordDto); given EmployeeRepository existsByEmployeeEmail(String) return 'false'")
    void testForgotPassword_givenEmployeeRepositoryExistsByEmployeeEmailReturnFalse() throws EmployeePasswordUpdationFailedException, ResourceNotFoundException {
        // Arrange
        when(employeeRepository.existsByEmployeeEmail(Mockito.<String>any())).thenReturn(false);

        // Act and Assert
        assertThrows(ResourceNotFoundException.class,
                () -> authService.forgotPassword(new ForgotPasswordDto("john.doe@example.com", "ruchi@123")));
        verify(employeeRepository).existsByEmployeeEmail(eq("john.doe@example.com"));
    }

    /**
     * Test {@link AuthService#forgotPassword(ForgotPasswordDto)} when password update fails.
     */
    @Test
    @DisplayName("Test forgotPassword(ForgotPasswordDto); when updateEmployeePassword fails")
    void testForgotPassword_updateEmployeePasswordFails() throws EmployeePasswordUpdationFailedException, ResourceNotFoundException {
        // Arrange
        when(employeeRepository.existsByEmployeeEmail(Mockito.<String>any())).thenReturn(true);
        when(employeeService.updateEmployeePassword(Mockito.<String>any(), Mockito.<String>any()))
                .thenThrow(new EmployeePasswordUpdationFailedException("Update failed"));

        // Act and Assert
        assertThrows(EmployeePasswordUpdationFailedException.class,
                () -> authService.forgotPassword(new ForgotPasswordDto("john.doe@example.com", "iloveyou")));
        verify(employeeRepository).existsByEmployeeEmail(eq("john.doe@example.com"));
    }

    /**
     * Test {@link AuthService#forgotPassword(ForgotPasswordDto)} when email is valid but update fails.
     */
    @Test
    @DisplayName("Test forgotPassword(ForgotPasswordDto); valid email but update fails")
    void testForgotPassword_validEmailButUpdateFails() throws EmployeePasswordUpdationFailedException, ResourceNotFoundException {
        // Arrange
        when(employeeRepository.existsByEmployeeEmail(Mockito.<String>any())).thenReturn(true);
        when(employeeService.updateEmployeePassword(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(false);  // Simulate update failure

        // Act
        boolean result = authService.forgotPassword(new ForgotPasswordDto("john.doe@example.com", "iloveyou"));

        // Assert
        assertFalse(result);
        verify(employeeRepository).existsByEmployeeEmail(eq("john.doe@example.com"));
    }

    /**
     * Test {@link AuthService#forgotPassword(ForgotPasswordDto)} when there is a RuntimeException.
     */
    @Test
    @DisplayName("Test forgotPassword(ForgotPasswordDto); given RuntimeException(String) with 'foo'; then throw RuntimeException")
    void testForgotPassword_givenRuntimeExceptionWithFoo_thenThrowRuntimeException() throws EmployeePasswordUpdationFailedException, ResourceNotFoundException {
        // Arrange
        when(employeeRepository.existsByEmployeeEmail(Mockito.<String>any())).thenReturn(true);
        ForgotPasswordDto forgotPasswordDto = mock(ForgotPasswordDto.class);
        when(forgotPasswordDto.getResetPassword()).thenThrow(new RuntimeException("foo"));
        when(forgotPasswordDto.getEmailOrPhone()).thenReturn("john.doe@example.com");

        // Act and Assert
        assertThrows(RuntimeException.class, () -> authService.forgotPassword(forgotPasswordDto));
        verify(forgotPasswordDto, atLeast(1)).getEmailOrPhone();
        verify(forgotPasswordDto).getResetPassword();
        verify(employeeRepository).existsByEmployeeEmail(eq("john.doe@example.com"));
    }
}
