package com.payswiff.mfmsproject;

import static org.mockito.Mockito.when;

import com.payswiff.mfmsproject.controllers.FeedbackController;
import com.payswiff.mfmsproject.reuquests.CreateFeedbackRequest;
import com.payswiff.mfmsproject.reuquests.FeedbackRequestWrapper;
import com.payswiff.mfmsproject.services.FeedbackService;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {FeedbackController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class FeedbackControllerTest {
    @Autowired
    private FeedbackController feedbackController;

    @MockBean
    private FeedbackService feedbackService;

    /**
     * Test {@link FeedbackController#createFeedback(FeedbackRequestWrapper)}.
     * <p>
     * Method under test:
     * {@link FeedbackController#createFeedback(FeedbackRequestWrapper)}
     */
    @Test
    @DisplayName("Test createFeedback(FeedbackRequestWrapper)")
    @Disabled("TODO: Complete this test")
    void testCreateFeedback() throws Exception {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Reason: No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   jakarta.servlet.ServletException: Request processing failed: java.lang.NullPointerException: Cannot invoke "java.util.Collection.size()" because "that" is null
        //       at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:590)
        //       at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:658)
        //   java.lang.NullPointerException: Cannot invoke "java.util.Collection.size()" because "that" is null
        //       at com.payswiff.mfmsproject.controllers.FeedbackController.createFeedback(FeedbackController.java:60)
        //       at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:590)
        //       at jakarta.servlet.http.HttpServlet.service(HttpServlet.java:658)
        //   See https://diff.blue/R013 to resolve this issue.

        // Arrange
        FeedbackController feedbackController = new FeedbackController();
        CreateFeedbackRequest feedbackRequest = CreateFeedbackRequest.builder()
                .feedback("Feedback")
                .feedbackDeviceId(1L)
                .feedbackEmployeeId(1L)
                .feedbackImage1("Feedback Image1")
                .feedbackMerchantId(1L)
                .feedbackRating(10.0d)
                .build();

        // Act
        feedbackController.createFeedback(new FeedbackRequestWrapper(feedbackRequest, null));
    }

    /**
     * Test
     * {@link FeedbackController#getFeedbacksByFilters(Long, Long, Integer, Long)}.
     * <p>
     * Method under test:
     * {@link FeedbackController#getFeedbacksByFilters(Long, Long, Integer, Long)}
     */
    @Test
    @DisplayName("Test getFeedbacksByFilters(Long, Long, Integer, Long)")
    void testGetFeedbacksByFilters() throws Exception {
        // Arrange
        when(feedbackService.getFeedbacksByFilters(Mockito.<Long>any(), Mockito.<Long>any(), Mockito.<Integer>any(),
                Mockito.<Long>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/feedback/getallfeedbacks");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(feedbackController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Test {@link FeedbackController#getAverageRatingByDevice()}.
     * <p>
     * Method under test: {@link FeedbackController#getAverageRatingByDevice()}
     */
    @Test
    @DisplayName("Test getAverageRatingByDevice()")
    void testGetAverageRatingByDevice() throws Exception {
        // Arrange
        when(feedbackService.getAverageRatingByDevice()).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/feedback/average-rating-by-device");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(feedbackController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Test {@link FeedbackController#getFeedbackCountByDevice()}.
     * <p>
     * Method under test: {@link FeedbackController#getFeedbackCountByDevice()}
     */
    @Test
    @DisplayName("Test getFeedbackCountByDevice()")
    void testGetFeedbackCountByDevice() throws Exception {
        // Arrange
        when(feedbackService.getFeedbackCountByDevice()).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/feedback/device-count");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(feedbackController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Test {@link FeedbackController#getAllFeedbacksCount()}.
     * <p>
     * Method under test: {@link FeedbackController#getAllFeedbacksCount()}
     */
    @Test
    @DisplayName("Test getAllFeedbacksCount()")
    void testGetAllFeedbacksCount() throws Exception {
        // Arrange
        when(feedbackService.countFeedbacksForAllEmployees()).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/feedback/allfeedbackscount");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(feedbackController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
