package com.payswiff.mfmsproject;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.payswiff.mfmsproject.exceptions.ResourceAlreadyExists;
import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.exceptions.ResourceUnableToCreate;
import com.payswiff.mfmsproject.models.Question;
import com.payswiff.mfmsproject.repositories.QuestionRepository;
import com.payswiff.mfmsproject.services.QuestionService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

@ExtendWith(SpringExtension.class)
class QuestionServiceTest {

    @Mock
    private QuestionRepository questionRepository;

    @InjectMocks
    private QuestionService questionService;

    @Test
    @DisplayName("Test saveQuestion: Success")
    void testSaveQuestionSuccess() throws ResourceAlreadyExists, ResourceUnableToCreate {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("Sample Question");

        when(questionRepository.findByDescription("Sample Question")).thenReturn(Optional.empty());
        when(questionRepository.save(question)).thenReturn(question);

        // Act
        Question savedQuestion = questionService.saveQuestion(question);

        // Assert
        assertNotNull(savedQuestion);
        assertEquals("Sample Question", savedQuestion.getQuestionDescription());
        verify(questionRepository).save(question);
    }

    @Test
    @DisplayName("Test saveQuestion: ResourceAlreadyExists exception")
    void testSaveQuestionThrowsResourceAlreadyExists() {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("Duplicate Question");

        when(questionRepository.findByDescription("Duplicate Question"))
            .thenReturn(Optional.of(question));

        // Act & Assert
        assertThrows(ResourceAlreadyExists.class, () -> questionService.saveQuestion(question));
    }

    @Test
    @DisplayName("Test saveQuestion: ResourceUnableToCreate exception")
    void testSaveQuestionThrowsResourceUnableToCreate() {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("New Question");

        when(questionRepository.findByDescription("New Question")).thenReturn(Optional.empty());
        when(questionRepository.save(question)).thenThrow(new RuntimeException("Database Error"));

        // Act & Assert
        assertThrows(ResourceUnableToCreate.class, () -> questionService.saveQuestion(question));
    }

    @Test
    @DisplayName("Test getQuestionById: Success")
    void testGetQuestionByIdSuccess() throws ResourceNotFoundException {
        // Arrange
        Question question = new Question();
        question.setQuestionId(1L);
        question.setQuestionDescription("Find by ID");

        when(questionRepository.findById(1L)).thenReturn(Optional.of(question));

        // Act
        Question foundQuestion = questionService.getQuestionById(1L);

        // Assert
        assertNotNull(foundQuestion);
        assertEquals(1L, foundQuestion.getQuestionId());
    }

    @Test
    @DisplayName("Test getQuestionById: ResourceNotFoundException")
    void testGetQuestionByIdThrowsResourceNotFoundException() {
        // Arrange
        when(questionRepository.findById(2L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> questionService.getQuestionById(2L));
    }

    @Test
    @DisplayName("Test getQuestionByDescription: Success")
    void testGetQuestionByDescriptionSuccess() throws ResourceNotFoundException {
        // Arrange
        Question question = new Question();
        question.setQuestionDescription("Find by Description");

        when(questionRepository.findByDescription("Find by Description"))
            .thenReturn(Optional.of(question));

        // Act
        Question foundQuestion = questionService.getQuestionByDescription("Find by Description");

        // Assert
        assertNotNull(foundQuestion);
        assertEquals("Find by Description", foundQuestion.getQuestionDescription());
    }

    @Test
    @DisplayName("Test getQuestionByDescription: ResourceNotFoundException")
    void testGetQuestionByDescriptionThrowsResourceNotFoundException() {
        // Arrange
        when(questionRepository.findByDescription("Unknown Description")).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> 
            questionService.getQuestionByDescription("Unknown Description"));
    }

    @Test
    @DisplayName("Test getAllQuestions: Returns list of questions")
    void testGetAllQuestions() {
        // Arrange
        Question question1 = new Question();
        question1.setQuestionDescription("Question 1");

        Question question2 = new Question();
        question2.setQuestionDescription("Question 2");

        when(questionRepository.findAll()).thenReturn(List.of(question1, question2));

        // Act
        List<Question> questions = questionService.getAllQuestions();

        // Assert
        assertEquals(2, questions.size());
        verify(questionRepository).findAll();
    }
}
