package com.payswiff.mfmsproject;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.payswiff.mfmsproject.exceptions.ResourceAlreadyExists;
import com.payswiff.mfmsproject.exceptions.ResourceNotFoundException;
import com.payswiff.mfmsproject.exceptions.ResourceUnableToCreate;
import com.payswiff.mfmsproject.models.Merchant;
import com.payswiff.mfmsproject.repositories.MerchantRepository;
import com.payswiff.mfmsproject.services.MerchantService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

@ExtendWith(SpringExtension.class)
class MerchantServiceTest {

    @Mock
    private MerchantRepository merchantRepository;

    @InjectMocks
    private MerchantService merchantService;

    @Test
    @DisplayName("Test createMerchant: Success")
    void testCreateMerchantSuccess() throws ResourceAlreadyExists, ResourceUnableToCreate {
        // Arrange
        Merchant merchant = new Merchant();
        merchant.setMerchantEmail("test@example.com");
        merchant.setMerchantPhone("1234567890");

        when(merchantRepository.findByMerchantEmailOrMerchantPhone(merchant.getMerchantEmail(), merchant.getMerchantPhone()))
            .thenReturn(null);
        when(merchantRepository.save(merchant)).thenReturn(merchant);

        // Act
        Merchant createdMerchant = merchantService.createMerchant(merchant);

        // Assert
        assertNotNull(createdMerchant);
        verify(merchantRepository).save(merchant);
    }

    @Test
    @DisplayName("Test createMerchant: ResourceAlreadyExists exception")
    void testCreateMerchantThrowsResourceAlreadyExists() {
        // Arrange
        Merchant merchant = new Merchant();
        merchant.setMerchantEmail("test@example.com");
        merchant.setMerchantPhone("1234567890");

        when(merchantRepository.findByMerchantEmailOrMerchantPhone(merchant.getMerchantEmail(), merchant.getMerchantPhone()))
            .thenReturn(merchant);

        // Act & Assert
        assertThrows(ResourceAlreadyExists.class, () -> merchantService.createMerchant(merchant));
    }

    @Test
    @DisplayName("Test createMerchant: ResourceUnableToCreate exception")
    void testCreateMerchantThrowsResourceUnableToCreate() {
        // Arrange
        Merchant merchant = new Merchant();
        merchant.setMerchantEmail("test@example.com");
        merchant.setMerchantPhone("1234567890");

        when(merchantRepository.findByMerchantEmailOrMerchantPhone(merchant.getMerchantEmail(), merchant.getMerchantPhone()))
            .thenReturn(null);
        when(merchantRepository.save(merchant)).thenThrow(new RuntimeException("Error saving merchant"));

        // Act & Assert
        assertThrows(ResourceUnableToCreate.class, () -> merchantService.createMerchant(merchant));
    }

    @Test
    @DisplayName("Test getMerchantByEmailOrPhone: Success")
    void testGetMerchantByEmailOrPhoneSuccess() throws ResourceNotFoundException {
        // Arrange
        Merchant merchant = new Merchant();
        merchant.setMerchantEmail("test@example.com");
        merchant.setMerchantPhone("1234567890");

        when(merchantRepository.findByMerchantEmailOrMerchantPhone("test@example.com", "1234567890"))
            .thenReturn(merchant);

        // Act
        Merchant foundMerchant = merchantService.getMerchantByEmailOrPhone("test@example.com", "1234567890");

        // Assert
        assertNotNull(foundMerchant);
        assertEquals("test@example.com", foundMerchant.getMerchantEmail());
    }

    @Test
    @DisplayName("Test getMerchantByEmailOrPhone: ResourceNotFoundException")
    void testGetMerchantByEmailOrPhoneThrowsResourceNotFoundException() {
        // Arrange
        when(merchantRepository.findByMerchantEmailOrMerchantPhone("test@example.com", "1234567890"))
            .thenReturn(null);

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> 
            merchantService.getMerchantByEmailOrPhone("test@example.com", "1234567890"));
    }

    @Test
    @DisplayName("Test getAllMerchants: Returns list of merchants")
    void testGetAllMerchants() {
        // Arrange
        Merchant merchant1 = new Merchant();
        Merchant merchant2 = new Merchant();

        when(merchantRepository.findAll()).thenReturn(List.of(merchant1, merchant2));

        // Act
        List<Merchant> merchants = merchantService.getAllMerchants();

        // Assert
        assertEquals(2, merchants.size());
        verify(merchantRepository).findAll();
    }

    @Test
    @DisplayName("Test existsById: Returns true if merchant exists")
    void testExistsByIdReturnsTrue() {
        // Arrange
        when(merchantRepository.existsById(1L)).thenReturn(true);

        // Act
        boolean exists = merchantService.existsById(1L);

        // Assert
        assertTrue(exists);
        verify(merchantRepository).existsById(1L);
    }

    @Test
    @DisplayName("Test existsById: Returns false if merchant does not exist")
    void testExistsByIdReturnsFalse() {
        // Arrange
        when(merchantRepository.existsById(1L)).thenReturn(false);

        // Act
        boolean exists = merchantService.existsById(1L);

        // Assert
        assertFalse(exists);
        verify(merchantRepository).existsById(1L);
    }
}
