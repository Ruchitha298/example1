package com.payswiff.mfmsproject;


import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payswiff.mfmsproject.controllers.MerchantController;
import com.payswiff.mfmsproject.models.Merchant;
import com.payswiff.mfmsproject.reuquests.CreateMerchantRequest;
import com.payswiff.mfmsproject.services.MerchantService;

import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {MerchantController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class MerchantControllerTest {
    @Autowired
    private MerchantController merchantController;

    @MockBean
    private MerchantService merchantService;

    /**
     * Test {@link MerchantController#createMerchant(CreateMerchantRequest)}.
     * <p>
     * Method under test:
     * {@link MerchantController#createMerchant(CreateMerchantRequest)}
     */
    @Test
    @DisplayName("Test createMerchant(CreateMerchantRequest)")
    void testCreateMerchant() throws Exception {
        // Arrange
        Merchant merchant = new Merchant();
        merchant.setMerchantBusinessName("Merchant Business Name");
        merchant.setMerchantBusinessType("Merchant Business Type");
        merchant.setMerchantCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        merchant.setMerchantEmail("jane.doe@example.org");
        merchant.setMerchantId(1L);
        merchant.setMerchantPhone("6625550144");
        merchant.setMerchantUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        merchant.setMerchantUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        when(merchantService.createMerchant(Mockito.<Merchant>any())).thenReturn(merchant);

        CreateMerchantRequest createMerchantRequest = new CreateMerchantRequest();
        createMerchantRequest.setMerchantBusinessName("Merchant Business Name");
        createMerchantRequest.setMerchantBusinessType("Merchant Business Type");
        createMerchantRequest.setMerchantEmail("jane.doe@example.org");
        createMerchantRequest.setMerchantPhone("6625550144");
        String content = (new ObjectMapper()).writeValueAsString(createMerchantRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/merchants/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);

        // Act
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(merchantController)
                .build()
                .perform(requestBuilder);

        // Assert
        actualPerformResult.andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"merchantId\":1,\"merchantUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"merchantEmail\":\"jane.doe@example"
                                        + ".org\",\"merchantPhone\":\"6625550144\",\"merchantBusinessName\":\"Merchant Business Name\",\"merchantBusinessType"
                                        + "\":\"Merchant Business Type\",\"merchantCreationTime\":[1970,1,1,0,0],\"merchantUpdationTime\":[1970,1,1,0,0"
                                        + "]}"));
    }

    /**
     * Test {@link MerchantController#getMerchantByEmailOrPhone(String, String)}.
     * <p>
     * Method under test:
     * {@link MerchantController#getMerchantByEmailOrPhone(String, String)}
     */
    @Test
    @DisplayName("Test getMerchantByEmailOrPhone(String, String)")
    void testGetMerchantByEmailOrPhone() throws Exception {
        // Arrange
        Merchant merchant = new Merchant();
        merchant.setMerchantBusinessName("Merchant Business Name");
        merchant.setMerchantBusinessType("Merchant Business Type");
        merchant.setMerchantCreationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        merchant.setMerchantEmail("jane.doe@example.org");
        merchant.setMerchantId(1L);
        merchant.setMerchantPhone("6625550144");
        merchant.setMerchantUpdationTime(LocalDate.of(1970, 1, 1).atStartOfDay());
        merchant.setMerchantUuid("01234567-89AB-CDEF-FEDC-BA9876543210");
        when(merchantService.getMerchantByEmailOrPhone(Mockito.<String>any(), Mockito.<String>any())).thenReturn(merchant);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/merchants/get");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(merchantController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isFound())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"merchantId\":1,\"merchantUuid\":\"01234567-89AB-CDEF-FEDC-BA9876543210\",\"merchantEmail\":\"jane.doe@example"
                                        + ".org\",\"merchantPhone\":\"6625550144\",\"merchantBusinessName\":\"Merchant Business Name\",\"merchantBusinessType"
                                        + "\":\"Merchant Business Type\",\"merchantCreationTime\":[1970,1,1,0,0],\"merchantUpdationTime\":[1970,1,1,0,0"
                                        + "]}"));
    }

    /**
     * Test {@link MerchantController#getAllMerchants()}.
     * <p>
     * Method under test: {@link MerchantController#getAllMerchants()}
     */
    @Test
    @DisplayName("Test getAllMerchants()")
    void testGetAllMerchants() throws Exception {
        // Arrange
        when(merchantService.getAllMerchants()).thenReturn(new ArrayList<>());
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/merchants/all");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(merchantController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("[]"));
    }
}

