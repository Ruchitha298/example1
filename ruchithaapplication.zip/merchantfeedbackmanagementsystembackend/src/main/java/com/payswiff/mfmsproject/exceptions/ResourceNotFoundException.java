package com.payswiff.mfmsproject.exceptions;

/**
 * Custom exception class that represents a "Resource Not Found" exception.
 * This exception is thrown when a requested resource (e.g., a Device or Merchant) 
 * is not found in the database.
 */
public class ResourceNotFoundException extends Exception {

    private static final long serialVersionUID = 1L;  // Serial version UID for serialization compatibility.

    private String resource;  // Name of the resource that is not found (e.g., "Device", "Merchant").
    private String field;     // Name of the field that was used to search for the resource (e.g., "ID", "Model").
    private String value;     // Value of the field that was searched for (e.g., "MPOS", "123").

    /**
     * Constructor for ResourceNotFoundException.
     * 
     * @param resource The resource type (e.g., "Device", "Merchant") that could not be found.
     * @param string2 
     * @param string 
     */
    public ResourceNotFoundException(String resource, String string, String string2) {
        // Construct a formatted error message using the provided resource, field, and value.
        super(String.format("%s with %s: %s is not found!!", resource, field, value));
        this.resource = resource;
        this.field = field;
        this.value = value;
    }

	public ResourceNotFoundException(String resource2) {
		// TODO Auto-generated constructor stub
	}

}
