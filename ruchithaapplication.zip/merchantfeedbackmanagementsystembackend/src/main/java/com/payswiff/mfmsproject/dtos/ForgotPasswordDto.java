package com.payswiff.mfmsproject.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor // Generates a no-argument constructor
@AllArgsConstructor // Generates an all-argument constructor
@Getter // Generates getter methods
@Setter // Generates setter methods

public class ForgotPasswordDto {
	
	private String emailOrPhone;
	private String resetPassword;
	
	 // No-argument constructor
    public ForgotPasswordDto() {
    }
    
	public ForgotPasswordDto(String emailOrPhone, String resetPassword) {
		this.emailOrPhone = emailOrPhone;
		this.resetPassword = resetPassword;
	}

	public String getEmailOrPhone() {
		return emailOrPhone;
	}

	public void setEmailOrPhone(String emailOrPhone) {
		this.emailOrPhone = emailOrPhone;
	}

	public String getResetPassword() {
		return resetPassword;
	}

	public void setResetPassword(String resetPassword) {
		this.resetPassword = resetPassword;
	}
	
}
